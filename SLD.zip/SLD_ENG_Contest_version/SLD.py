import tkinter as tk
from tkinter import Label, filedialog, font, Toplevel, StringVar, OptionMenu, messagebox
import cv2
from PIL import Image, ImageTk
from deepface import DeepFace
import numpy as np
import joblib
import os
import sys
import tempfile


def resource_path(*parts):

    if hasattr(sys, '_MEIPASS'):
        base_path = sys._MEIPASS 
    else:
        base_path = os.path.abspath(os.path.dirname(__file__))

    return os.path.join(base_path, *parts)


model_path = resource_path("models", "stress_svm_model.pkl")

try:
    clf, scaler = joblib.load(model_path)
    print("SVM-model and scaler integrated.")
except Exception as e:
    clf = None
    scaler = None
    print(f"SVM-error: {e}")


window = tk.Tk()
window.title("Stress level detect")
window.configure(bg="#BDFAF8")
window.geometry("1100x670")
window.resizable(False, False)
window.overrideredirect(False)


current_image_path = None
current_camera_index = 0
cap = cv2.VideoCapture(current_camera_index)
current_frame = None
preview_update_id = None
settings_window_open = False
about_window_open = False

base_font_size = 10
header_font = font.Font(family="Helvetica", size=15, weight="bold")
button_font = font.Font(family="Helvetica", size=15)
title_font = font.Font(family="Helvetica", size=24, weight="bold")


def create_rounded_button(parent, y, width, height, radius, text, command, bg="#5FB1E8", fg="white"):
    c = tk.Canvas(parent, width=width, height=height, bg=parent["bg"], highlightthickness=0)
    c.create_arc((0, 0, radius*2, radius*2), start=90, extent=90, fill=bg, outline=bg)
    c.create_arc((width - radius*2, 0, width, radius*2), start=0, extent=90, fill=bg, outline=bg)
    c.create_arc((0, height - radius*2, radius*2, height), start=180, extent=90, fill=bg, outline=bg)
    c.create_arc((width - radius*2, height - radius*2, width, height), start=270, extent=90, fill=bg, outline=bg)
    c.create_rectangle(radius, 0, width - radius, height, fill=bg, outline=bg)
    c.create_rectangle(0, radius, width, height - radius, fill=bg, outline=bg)
    c.create_text(width/2, height/2, text=text, fill=fg, font=button_font)
    c.bind("<Button-1>", lambda e: command())
    c.place(x=20, y=y)
    return c


def get_visuals(stress_level):
    level_lower = stress_level.lower()
    if level_lower == "low":
        return "#A8E6CF", resource_path("assets", "low_stress.png")
    elif level_lower == "medium":
        return "#F5CF52", resource_path("assets", "medium_stress.png")
    elif level_lower == "high":
        return "#FF8B94", resource_path("assets", "high_stress.png")
    else:
        return "#BDFAF8", resource_path("assets", "default.png") 

def get_logo():
    return resource_path("assets", "Logo.png")


def update_preview():
    global preview_update_id
    if preview_label.winfo_ismapped():
        ret, frame = cap.read()
        if ret:
            frame_resized = cv2.resize(frame, (760, 600))
            frame_rgb = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(frame_rgb)
            imgtk = ImageTk.PhotoImage(image=img)
            preview_label.imgtk = imgtk
            preview_label.configure(image=imgtk)
            preview_label.lift()
    preview_update_id = window.after(10, update_preview)


def switch_camera():
    global cap, current_camera_index, preview_update_id
    if preview_update_id:
        window.after_cancel(preview_update_id)
    current_camera_index = 1 - current_camera_index
    cap.release()
    cap = cv2.VideoCapture(current_camera_index)
    update_preview()



def start_recognition():
    global current_frame, current_image_path

    if not clf:
        messagebox.showerror("Model Error", "SVM model not loaded! Cannot proceed.")
        return

    if current_image_path is None and current_frame is None:
        messagebox.showerror("Error", "Take a snapshot or select an image.")
        return

    if current_image_path is not None:
        file_path = current_image_path
    else:
        temp_dir = tempfile.gettempdir()
        temp_file_path = os.path.join(temp_dir, "temp_image.jpg")

        if current_frame is not None:
            success = cv2.imwrite(temp_file_path, current_frame)
            if not success:
                messagebox.showerror("Error", "Temporary image could not be saved.")
                return
            file_path = temp_file_path
        else:
            messagebox.showerror("Error", "No image data from camera.")
            return

    try:
        color_frame = cv2.imread(file_path)
        if color_frame is None:
            raise ValueError(f"Could not open image at path: {file_path}")

        emb_list = DeepFace.represent(
            img_path=file_path,
            model_name="VGG-Face",
            enforce_detection=False
        )
        if not emb_list:
            raise ValueError("No face embedding found. Possibly no face detected.")

        embedding = np.array(emb_list[0]['embedding']).reshape(1, -1)

        if scaler is not None:
            embedding = scaler.transform(embedding)

        predicted_label = clf.predict(embedding)[0]


        bg_color, icon_path = get_visuals(predicted_label)

        frame_resized = cv2.resize(color_frame, (760, 600))
        frame_rgb = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(frame_rgb)
        imgtk = ImageTk.PhotoImage(image=img)
        snapshot_label.configure(image=imgtk)
        snapshot_label.imgtk = imgtk


        result_window = Toplevel(window)
        result_window.title("Result")
        result_window.geometry("500x300")
        result_window.configure(bg=bg_color)

        msg = f"Stress level: {predicted_label}"
        Label(result_window, text=msg, font=button_font, bg=bg_color,
              wraplength=350, justify="center").pack(pady=10)

        emoji_img = Image.open(icon_path).resize((120, 120))
        emoji_tk = ImageTk.PhotoImage(emoji_img)
        emoji_label = Label(result_window, image=emoji_tk, bg=bg_color)
        emoji_label.image = emoji_tk
        emoji_label.pack(pady=10)

        close_btn = tk.Button(result_window, text="Close", command=result_window.destroy,
                              font=button_font, bg="#4CAF50", fg="white", relief="flat")
        close_btn.pack(pady=10)

    except Exception as e:
        messagebox.showerror("Analysis error", f"An error occurred: {str(e)}")


def take_snapshot():
    global current_frame
    ret, frame = cap.read()
    if ret:
        current_frame = frame.copy()
        frame_resized = cv2.resize(frame, (760, 600))
        frame_rgb = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(frame_rgb)
        imgtk = ImageTk.PhotoImage(image=img)

        preview_label.place_forget()
        snapshot_label.place(x=280, y=30)
        snapshot_label.imgtk = imgtk
        snapshot_label.configure(image=imgtk)

        hide_all_buttons()
        btn_start.place(x=20, y=280)
        btn_cancel.place(x=20, y=340)
    else:
        messagebox.showerror("Error", "Failed to capture image from camera.")


def cancel_action():
    global current_image_path, current_frame
    current_image_path = None
    current_frame = None

    snapshot_label.configure(image="")
    snapshot_label.imgtk = None
    snapshot_label.place_forget()

    preview_label.place(x=280, y=30)
    preview_label.lift()
    show_all_buttons()


def choose_file():
    global current_image_path
    file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.jpg *.jpeg *.png")])
    if file_path:
        current_image_path = file_path
        img = Image.open(file_path).resize((760, 600))
        imgtk = ImageTk.PhotoImage(image=img)

        preview_label.place_forget()
        snapshot_label.place(x=280, y=30)
        snapshot_label.imgtk = imgtk
        snapshot_label.configure(image=imgtk)

        hide_all_buttons()
        btn_start.place(x=20, y=280)
        btn_cancel.place(x=20, y=340)


def show_about():
    global about_window_open
    if about_window_open:
        return
    about_window_open = True
    a_window = Toplevel(window)
    a_window.title("About the app")
    a_window.geometry("610x550")
    a_window.configure(bg="#BDFAF8")

    def on_close():
        global about_window_open
        about_window_open = False
        a_window.destroy()

    a_window.protocol("WM_DELETE_WINDOW", on_close)

    about_text = (
        "Welcome to the program 'SLD'!\n\n"
        "This program is created to analyze stress levels using facial recognition technology.\n"
        "User's guide:\n"
        "1. **Using a camera:**\n"
        "   - 'Take a picture' button takes a photo of your face.\n"
        "   - 'Switch camera' button changes the main camera to an external one.\n"
        "   - 'Select image from files' button allows you to choose a photo.\n\n"
        "2. **Image analysis:**\n"
        "   - After taking a picture or uploading a photo, click 'Start recognition' to see the result.\n\n"
        "Note: The program depends on the image quality and lighting. For accurate analysis, make sure the face is clearly visible.\n"
    )

    Label(a_window, text=about_text, font=button_font, bg="#BDFAF8",
          wraplength=590, justify="left").pack(pady=20)
    create_rounded_button(a_window, 490, 200, 40, 10, "Close", on_close)


def hide_all_buttons():
    btn_capture.place_forget()
    btn_choose_file.place_forget()
    btn_about.place_forget()
    btn_switch_camera.place_forget()


def show_all_buttons():
    btn_capture.place(x=20, y=160)
    btn_choose_file.place(x=20, y=220)
    btn_about.place(x=20, y=280)
    btn_switch_camera.place(x=20, y=340)
    btn_cancel.place_forget()
    btn_start.place_forget()


logo_path = get_logo()
logo_img = Image.open(logo_path).resize((150, 120), Image.LANCZOS)
logo_imgtk = ImageTk.PhotoImage(logo_img)
logo_label = Label(window, image=logo_imgtk, bg="#BDFAF8")
logo_label.image = logo_imgtk
logo_label.place(x=30, y=20)

label_text = Label(window, text="", font=header_font, bg="#BDFAF8",
                   fg="#333", wraplength=640)
label_text.place(x=280, y=520)

btn_capture = create_rounded_button(window, 160, 200, 40, 15, "Take snapshot", take_snapshot)
btn_choose_file = create_rounded_button(window, 220, 200, 40, 15, "Upload image", choose_file)
btn_about = create_rounded_button(window, 280, 200, 40, 15, "User's guide", show_about)
btn_start = create_rounded_button(window, 280, 200, 40, 15, "Start recognition", start_recognition)
btn_cancel = create_rounded_button(window, 340, 200, 40, 15, "Cancel", cancel_action)
btn_switch_camera = create_rounded_button(window, 340, 200, 40, 15, "Switch camera", switch_camera)
btn_cancel.place_forget()
btn_start.place_forget()

preview_label = Label(window, bg="#333", width=760, height=600)
preview_label.place(x=280, y=30)
snapshot_label = Label(window, bg="#BDFAF8")

update_preview()
window.mainloop()
cap.release()
