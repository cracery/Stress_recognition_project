import os
import subprocess
import sys

def install_pip():
    try:
        import pip
        print("pip is installed.")
    except ImportError:
        print("No pip found, trying to install...")
        subprocess.run([sys.executable, "-m", "ensurepip", "--default-pip"], check=True)
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"], check=True)
        print("pip installed!")

def install_packages():
    required_packages = [
        "numpy==1.26.4",
        "tensorflow==2.10.1",
        "keras==2.10.0",
        "opencv-python==4.11.0.86",
        "deepface==0.0.79",
        "scikit-learn==1.6.1",
        "joblib==1.4.2",
        "pillow==11.1.0",
        "pyinstaller==6.12.0",
        "pandas==2.2.3"
    ]

    import_map = {
        "numpy": "numpy",
        "tensorflow": "tensorflow",
        "keras": "keras",
        "opencv-python": "cv2",
        "deepface": "deepface",
        "scikit-learn": "sklearn",
        "joblib": "joblib",
        "pillow": "PIL",
        "pyinstaller": "PyInstaller",
        "pandas": "pandas"
    }

    print("=== Checking and installing required libraries ===")
    for pkg in required_packages:
        base_name = pkg.split("==")[0].strip()

        short_name = import_map.get(base_name, base_name)
        try:
            __import__(short_name)
            print(f"{pkg} - already installed.")
        except ImportError:
            print(f"Installing {pkg}...")
            subprocess.run([sys.executable, "-m", "pip", "install", pkg], check=True)

    print("All packages are installed/updated successfully!")


if __name__ == "__main__":
    install_pip()
    install_packages()
